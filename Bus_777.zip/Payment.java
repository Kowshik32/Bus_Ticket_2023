public class Payment {
    private int amouont;
    private int otp=1234;
    void setAmouont(int wn){
        this.amouont=150*wn;
    }
    int getAmouont(){
        return amouont;
    }
    int getOtp(){
        return otp;
    }
}
