public class Devloper {
    void dev()
    {
        System.out.println("Mithun Kumar das");
        System.out.println("213-35-796");
        System.out.println("b.sc in SWE At Diu");
    }

    void help()
    {
        System.out.println("help.public@gmail.com");
        System.out.println("Number_ 888");
    }
}
